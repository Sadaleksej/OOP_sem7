package ru.geekbrains.lesson7.factory;

public enum EmployeeType {
    Worker,
    Freelancer
}
