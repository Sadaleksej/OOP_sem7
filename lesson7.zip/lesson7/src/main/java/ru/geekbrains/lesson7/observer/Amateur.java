package ru.geekbrains.lesson7.observer;

import java.util.Objects;

public class Amateur implements Observer{

    private String name;

    public Amateur(String name) {
        this.name = name;
    }

    private int salary = 24000;

    private String vacancy = "Подмастерье";

    @Override
    public void receiveOffer(String nameCompany, int salary, String vacancy) {
        if (this.salary <= salary & Objects.equals(vacancy, "Подмастерье")){
            System.out.printf("Новичок %s: Мне нужна эта работа! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
            this.salary = salary;
        }
        else {
            System.out.printf("Новичок %s: Я найду работу получше! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
        }
    }

}