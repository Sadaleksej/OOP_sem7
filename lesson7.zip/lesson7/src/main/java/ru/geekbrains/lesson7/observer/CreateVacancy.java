package ru.geekbrains.lesson7.observer;

import ru.geekbrains.lesson7.factory.EmployeeType;

import java.util.Random;

public class CreateVacancy {

    static Random random = new Random();
    public String GetVacancy (){

            int Index = random.nextInt(4);
            return switch (Index)
                     {
                case 0 -> VacancyType.V1.getVacName();
                case 1 -> VacancyType.V2.getVacName();
                case 2 -> VacancyType.V3.getVacName();
                case 3 -> VacancyType.V4.getVacName();
                default -> null;
            };


    }
}
