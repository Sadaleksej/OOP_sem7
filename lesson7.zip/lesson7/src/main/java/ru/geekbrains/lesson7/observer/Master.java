package ru.geekbrains.lesson7.observer;

import java.util.Objects;

public class Master implements Observer{

    private String name;

    public Master(String name) {
        this.name = name;
    }

    private int salary = 80000;

    private String vacancy = "Старший группы";

    @Override
    public void receiveOffer(String nameCompany, int salary, String vacancy) {
        if (this.salary <= salary & Objects.equals(vacancy, "Старший группы")){
            System.out.printf("Специалист %s: Мне нужна эта работа! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
            this.salary = salary;
        }
        else {
            System.out.printf("Специалист %s: Я найду работу получше! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
        }
    }

}
