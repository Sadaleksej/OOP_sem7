package ru.geekbrains.lesson7.observer;

import java.util.Objects;

public class Superviser implements Observer{

    private String name;

    public Superviser(String name) {
        this.name = name;
    }

    private int salary = 78000;

    private String vacancy = "Начальник";

    @Override
    public void receiveOffer(String nameCompany, int salary, String vacancy) {
        if (this.salary <= salary & Objects.equals(vacancy, "Начальник")){
            System.out.printf("Супервайзер %s: Мне нужна эта работа! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
            this.salary = salary;
        }
        else {
            System.out.printf("Супервайзер %s: Я найду работу получше! (компания: %s; заработная плата: %d; вакансия: %s)\n",
                    name, nameCompany, salary, vacancy);
        }
    }

}
