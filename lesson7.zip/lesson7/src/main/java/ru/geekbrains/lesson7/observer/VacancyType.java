package ru.geekbrains.lesson7.observer;

public enum VacancyType {

    V1("Старший группы", 1),
    V2("Подмастерье", 2),
    V3("Помощьник", 3),
    V4("Начальник", 4);


    private String vac_name;
    private int vac_index;

    VacancyType(String vac_name, int vac_index) {
        this.vac_name = vac_name;
        this.vac_index = vac_index;
    }



    public String getVacName() {
        return vac_name;
    }

    public void setVacName(String name) {
        this.vac_name = name;
    }

    public int getVacIndex() {
        return vac_index;
    }

    public void setVacIndex(int index) {
        this.vac_index = index;
    }


}
